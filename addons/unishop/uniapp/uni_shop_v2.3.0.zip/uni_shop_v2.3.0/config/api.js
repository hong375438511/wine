const http = uni.$u.http

// 全部收货地址
export const AddressAll = (params) => http.post('addons/unishop/address/all', params)
// 添加收货地址
export const AddressAdd = (params) => http.post('addons/unishop/address/add', params)
// 修改收货地址
export const AddressEdit = (params) => http.post('addons/unishop/address/edit', params)
// 删除收货地址
export const AddressDelete = (params) => http.post('addons/unishop/address/delete', params)
// 获取地区信息
export const AddressArea = (params) => http.post('addons/unishop/address/area', params)
// 获取单个收货地址
export const AddressInfo = (params) => http.post('addons/unishop/address/info', params)

// 广告列表
export const AdsIndex = (p) => http.post('addons/unishop/ads/index', p)

// 购物车列表
export const CartIndex = (p) => http.post('addons/unishop/cart/index', p)
// 添加商品到购物车
export const CartAdd = (p) => http.post('addons/unishop/cart/add', p)
// 删除购物车的商品支持多个删除用','号隔开购物车id
export const CartDelete = (p) => http.post('addons/unishop/cart/delete', p)
// 修改购物车数量
export const CartNumberChange = (p) => http.post('addons/unishop/cart/number_change', p)
// 修改购物车选中状态
export const CartChooseChange = (p) => http.post('addons/unishop/cart/choose_change', p)

// 全部分类数据
export const CategoryAll = (p) => http.post('addons/unishop/category/all', p)
// 首页广告下面的分类
export const CategoryMenu = (p) => http.post('addons/unishop/category/menu', p)
// 首页tabs
export const CategoryTabs = (p) => http.post('addons/unishop/category/tabs', p)

// 首页秒杀信息
export const FlashIndex = (p) => http.post('addons/unishop/flash/index', p)
// 获取秒杀时间段
export const FlashNavbar = (p) => http.post('addons/unishop/flash/navbar', p)
// 获取秒杀的产品列表
export const FlashProduct = (p) => http.post('addons/unishop/flash/product', p)
// 获取秒杀产品
export const FlashProductDetail = (p) => http.post('addons/unishop/flash/productDetail', p)
// 创建订单
export const FlashCreateOrder = (p) => http.post('addons/unishop/flash/createOrder', p)
// 提交订单
export const FlashSubmitOrder = (p) => http.post('addons/unishop/flash/submitOrder', p)

// 创建订单
export const OrderCreate = (p) => http.post('addons/unishop/order/create', p)
// 提交订单
export const OrderSubmit = (p) => http.post('addons/unishop/order/submit', p)
// 获取运费模板
export const OrderGetDelivery = (p) => http.post('addons/unishop/order/getDelivery', p)
// 获取订单列表
export const OrderGetOrders = (p) => http.post('addons/unishop/order/getOrders', p)
// 取消订单
export const OrderCancel = (p) => http.post('addons/unishop/order/cancel', p)
// 删除订单
export const OrderDelete = (p) => http.post('addons/unishop/order/delete', p)
// 确认收货
export const OrderReceived = (p) => http.post('addons/unishop/order/received', p)
// 发表评论/评价
export const OrderComment = (p) => http.post('addons/unishop/order/comment', p)
// 获取订单数量
export const OrderCount = (p) => http.post('addons/unishop/order/count', p)
// 订单详情细节
export const OrderDetail = (p) => http.post('addons/unishop/order/detail', p)
// 申请售后信息
export const OrderRefundInfo = (p) => http.post('addons/unishop/order/refundInfo', p)
// 提交申请售后
export const OrderRefund = (p) => http.post('addons/unishop/order/refund', p)
// 售后发货
export const OrderRefundDelivery = (p) => http.post('addons/unishop/order/refundDelivery', p)
// 快递查询
export const OrderExpress = (p) => http.post('addons/unishop/order/express', p)

// 获取支付类型
export const PayGetPayType = (p) => http.post('addons/unishop/pay/getPayType', p)
// 微信统一下单接口
export const PayUnify = (p) => http.post('addons/unishop/pay/unify', p)
// 货到付款
export const PayOffline = (p) => http.post('addons/unishop/pay/offline', p)
// 获取JSAPI配置
export const PayJssdkBuildConfig = (p) => http.post('addons/unishop/pay/jssdkBuildConfig', p)
// 支付宝支付
export const PayAlipay = (p) => http.post('addons/unishop/pay/alipay', p)

// 产品详情
export const ProductDetail = (p) => http.post('addons/unishop/product/detail', p)
// 产品列表
export const ProductLists = (p) => http.post('addons/unishop/product/lists', p)
// 收藏
export const ProductFavorite = (p) => http.post('addons/unishop/product/favorite', p)
// 收藏列表
export const ProductFavoriteList = (p) => http.post('addons/unishop/product/favoriteList', p)
// 商品评论
export const ProductEvaluate = (p) => http.post('addons/unishop/product/evaluate', p)

// 发送短信
export const SmsSend = (p) => http.post('addons/unishop/sms/send', p)

// 会员登录
export const UserLogin = (p) => http.post('addons/unishop/user/login', p)
// 重置密码
export const UserResetpwd = (p) => http.post('addons/unishop/user/resetpwd', p)
// 注册会员
export const UserRegister = (p) => http.post('addons/unishop/user/register', p)
// 更改用户信息
export const UserEdit = (p) => http.post('addons/unishop/user/edit', p)
// 微信小程序登录
export const UserAuthSession = (p) => http.post('addons/unishop/user/authSession', p)
// 微信小程序消息解密
export const UserDecryptData = (p) => http.post('addons/unishop/user/decryptData', p)
// 微信小程序通过授权手机号登录
export const UserLoginForWechatMini = (p) => http.post('addons/unishop/user/loginForWechatMini', p)
