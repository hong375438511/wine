# uniShop

#### 介绍
{**本项目简称uniShop,是一个完整的商城。基于[uniapp框架](https://uniapp.dcloud.io/)开发。**}

#### 体验
![微信小程序](https://images.gitee.com/uploads/images/2020/0415/215327_77d28dac_1588098.jpeg "微信小程序")

#### 后台演示
1.  后端演示地址 [后端地址](http://demo.shop.weivee.com/admin) http://demo.shop.weivee.com/admin

#### 后台源码
1.  后端源码地址 [源码地址](https://www.fastadmin.net/store/unishop.html) https://www.fastadmin.net/store/unishop.html 

#### 安装教程

1.  git clone 下来之后直接在HBuilderX打开即可
2.  接口地址在main.js修改

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 特别鸣谢

1.  uni-app https://uniapp.dcloud.io/
2.  mix-mall https://ext.dcloud.net.cn/plugin?id=200
3.  mpvue-citypicker https://github.com/MPComponent/mpvue-citypicker  
4.  vue.js https://cn.vuejs.org/


#### 版权信息

unishop遵循MIT开源协议发布，并提供免费使用。

本项目包含的第三方源码和二进制文件之版权信息另行标注。

版权所有Copyright © 2020 by uniShop

All rights reserved。