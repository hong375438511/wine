<template>
	<view>
		<u-tabbar activeColor="#fa436a" :value="value" @change="change" :fixed="true" :placeholder="false"
			:safeAreaInsetBottom="true">
			<u-tabbar-item text="首页" @click="click">
				<u-icon name="home-fill" slot="active-icon" color="#fa436a" size="56"></u-icon>
				<u-icon name="home-fill" slot="inactive-icon" color="#414141" size="56"></u-icon>
			</u-tabbar-item>
			<u-tabbar-item text="分类" @click="click">
				<u-icon name="grid-fill" slot="active-icon" color="#fa436a" size="56"></u-icon>
				<u-icon name="grid-fill" slot="inactive-icon" color="#414141" size="56"></u-icon>
			</u-tabbar-item>
			<u-tabbar-item text="购物车" @click="click">
				<u-icon name="shopping-cart-fill" slot="active-icon" color="#fa436a" size="56"></u-icon>
				<u-icon name="shopping-cart-fill" slot="inactive-icon" color="#414141" size="56"></u-icon>
			</u-tabbar-item>
			<u-tabbar-item text="用户" @click="click">
				<u-icon name="account-fill" slot="active-icon" color="#fa436a" size="56"></u-icon>
				<u-icon name="account-fill" slot="inactive-icon" color="#414141" size="56"></u-icon>
			</u-tabbar-item>
		</u-tabbar>
	</view>
</template>

<script>
	export default {
		name: "tabbar",
		props: {
			value: {
				type: Number,
				default: 0
			},
		},
		methods: {
			click(e) {
				if (this.value == e) {
					return;
				}
				switch (e) {
					case 0:
						uni.$u.route({
							url: '/pages/index/index',
							type: 'redirectTo'
						});
						break;
					case 1:
						uni.$u.route({
							url: '/pages/category/category',
							type: 'redirectTo'
						});
						break;
					case 2:
						uni.$u.route({
							url: '/pages/cart/cart',
							type: 'redirectTo'
						});
						break;
					case 3:
						uni.$u.route({
							url: '/pages/user/user',
							type: 'redirectTo'
						});
						break;
				}
			},
			change(e) {

			},
		}
	}
</script>

<style lang="scss">

</style>